update lb_user
 set user_name=${user_name<STRING>},
     user_tel=${user_tel<STRING>},
	 user_acc=${user_acc<STRING>},
	 user_opt=${user_opt<STRING>},
	 user_pwd=${user_pwd<STRING>}
where user_id = ${id<INT>}