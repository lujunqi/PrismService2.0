insert into lb_user
(user_name,user_tel,user_acc,user_pwd,user_opt)
values 
(${user_name<STRING>},${user_tel<STRING>},${user_acc<STRING>},${user_pwd<STRING>},${user_opt<STRING>})