INSERT INTO lb_gather (
	gather_name,
	gather_co,
	gather_tel,
	gather_type,
	gather_level,
	gather_weixin,
	gather_weixin_jion,
	gather_area,
	gather_address,
	gather_card,
	
	user_id
)
VALUES
	(
	${gather_name<STRING>},
	${gather_co<STRING>},
	${gather_tel<STRING>},
	${gather_type<STRING>},
	${gather_level<STRING>},
	${gather_weixin<STRING>},
	${gather_weixin_jion<STRING>},
	${gather_area<STRING>},
	${gather_address<STRING>},
	${gather_card<STRING>},
	
	${session.get('user_id')<INT>}
)