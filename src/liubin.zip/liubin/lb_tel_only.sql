SELECT 1 AS TEL FROM v_lb_cust_info c where c.cust_tel = ${tel<STRING>}
UNION ALL
SELECT 1 FROM v_lb_gather G WHERE G.gather_tel =  ${tel<STRING>}