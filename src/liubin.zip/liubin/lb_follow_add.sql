INSERT INTO lb_follow (
	follow_info,
	follow_type,
	follow_name,
	other_id	
)
VALUES
(
	${follow_info<STRING>},
	${follow_type<STRING>},
	${session.get('user_name')<STRING>},
	${other_id<INT>}
)